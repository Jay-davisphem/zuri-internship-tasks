"""Add two numbers and print the results to the terminal"""


def add_two_numbers(num1: float, num2: float) -> float:
    """add two numbers"""
    return num1 + num2


if __name__ == "__main__":
    NUM1 = 245
    NUM2 = 456
    ADD_NUMS = NUM1 + NUM2
    print(ADD_NUMS)
